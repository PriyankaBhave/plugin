jQuery(document).ready(function(){
	jQuery(".wlog_select_page").on("change",function(){
		var redirect = jQuery(this).next().val("");
	});
	jQuery(".redirect_link").on("focus",function(){
		var redirect = jQuery(this).prev().prop('selectedIndex',0);
	});
});