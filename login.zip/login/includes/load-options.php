<?php
class WLOG_options_login {
	public function __construct() {
		$this->WLOG_load_settings();        
	}
	public function WLOG_load_settings(){
		add_action('admin_menu', array($this,'WLOG_add_settings_page'));
		add_action('admin_enqueue_scripts', array($this,'WLOG_add_scripts'));
    }
    public function WLOG_add_settings_page(){   
    	if(!is_admin() || !current_user_can('manage_options'))
			return; 	
    	add_submenu_page( 
	        'options-general.php',
	        'Login/Logout settings',
	        'Login/Logout settings',
	        'manage_options',
	        'login-logout-settings',
	        array($this,'WLOG_login_logout_settings')
	    );
    }
    // verify nonce
    //wp_verify_nonce( $_POST['name_of_nonce_field'], 'name_of_my_action' ) 

    public function WLOG_login_logout_settings(){
    	if(!is_admin() || !current_user_can('manage_options'))
			return;

		?>
		<div class="settings_div">
			<h1>Redirection settings after login/ logout</h1>
			<form action="" method="POST">
				<?php wp_nonce_field( '_set_options', '_update_sett_nonce',true,false ); ?>
				<h2>Subscribers</h2>
				<table class="settings_table">
					<thead>
						<tr>
							<th><h3>Action</h3></th>
							<th><h3>Redirect to</h3></th>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td>Login</td>
							<td><input name="login_subscriber" id="login_subscriber" placeholder="Enter redirection url after login" value="<?php ?>"/></td>
						</tr>
						<tr>
							<td>Logout</td>
							<td><input name="logout_subscriber" id="logout_subscriber" placeholder="Enter redirection url after logout" value="<?php ?>"/></td>
						</tr>
					</tbody>
				</table>

				<h2>Admin</h2>
				<table class="settings_table">
					<thead>
						<tr>
							<th><h3>Action</h3></th>
							<th><h3>Redirect to</h3></th>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td>Login</td>
							<td><input name="login_admin" id="login_admin" placeholder="Enter redirection url after login" value="<?php ?>"/></td>
						</tr>
						<tr>
							<td>Logout</td>
							<td><input name="logout_admin" id="logout_admin" placeholder="Enter redirection url after logout" value="<?php ?>"/></td>
						</tr>
					</tbody>
				</table>
				<input type="submit" name="update_settings" id="update_settings" value="Update"/>
			</form>
		</div>
		<?php
    }

    function WLOG_add_scripts(){
    	wp_enqueue_style('wlog-admin-style', WLOG_direct_url. 'assets/css/login-settings.css');
    }
}

// add_filter( 'wp_nav_menu_items', 'add_loginout_link', 10, 2 );
// function add_loginout_link( $items, $args ) {
//     if (is_user_logged_in() && $args->theme_location == 'primary') {
//         $items .= '<li><a href="'. wp_logout_url() .'">Log Out</a></li>';
//     }
//     elseif (!is_user_logged_in() && $args->theme_location == 'primary') {
//         $items .= '<li><a href="'. site_url('wp-login.php') .'">Log In</a></li>';
//     }
//     return $items;
// }

// function my_special_nav_class( $classes, $item ) {

//     if ( is_single() && $item->title == 'Blog' ) {
//         $classes[] = 'special-class';
//     }

//     return $classes;

// }

// add_filter( 'nav_menu_css_class', 'my_special_nav_class', 10, 2 );

// #container {
//     width: 100%;
//     height: 100%;
//     top: 0;
//     position: absolute;
//     visibility: hidden;
//     display: none;
//     background-color: rgba(22,22,22,0.5);  complimenting your modal colors 
// }
// #container:target {
//     visibility: visible;
//     display: block;
// }
// .reveal-modal {
//     position: relative;
//     margin: 0 auto;
//     top: 25%;
// }

// <a href="#container">Reveal</a>
// <div id="container">
//     <div id="exampleModal" class="reveal-modal">
//     ........
//     <a href="#">Close Modal</a>
//     </div>
// </div>

// .holder{        
//     width:100%;
//     display:block;
// }
// .content{
//     background:#fff;
//     padding: 28px 26px 33px 25px;
// }
// .popup{
//     border-radius: 7px;
//     background:#6b6a63;
//     margin:30px auto 0;
//     padding:6px;  
//     // here it comes
//     position:absolute;
//     width:800px;
//     top: 50%;
//     left: 50%;
//     margin-left: -400px; // 1/2 width
//     margin-top: -40px; // 1/2 height
// }

// <div class="holder">     
//     <div id="popup" class="popup">            
//         <div class="content">some lengthy text</div>
//     </div>
// </div>