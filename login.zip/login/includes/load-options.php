<?php
class WLOG_options_login {
	protected $items_classes='';
	public function __construct() {
		$this->WLOG_load_settings();        
	}
	public function WLOG_load_settings(){
		add_action('admin_menu', array($this,'WLOG_add_settings_page'));
		add_action('admin_enqueue_scripts', array($this,'WLOG_add_scripts'));
		add_action('wp_enqueue_scripts', array($this,'WLOG_add_scriptsFrontend'));
		add_filter( 'wp_nav_menu_items', array($this,'WLOG_add_loginout_link'), 10, 2 );
		add_filter( 'nav_menu_css_class', array($this,'WLOG_get_nav_class'), 10, 2 );
		add_action( 'admin_init', array($this,'WLOG_update_options'), 10, 2 );
		add_action( 'wp_loaded', array($this,'WLOG_create_login') );
    }
    public function WLOG_add_settings_page(){   
    	if(!is_admin() || !current_user_can('manage_options'))
			return; 	
    	add_submenu_page( 
	        'options-general.php',
	        'Login/Logout settings',
	        'Login/Logout settings',
	        'manage_options',
	        'login-logout-settings',
	        array($this,'WLOG_login_logout_settings')
	    );
    } 
    public function WLOG_update_options(){
    	if(!is_admin() || !current_user_can('manage_options'))
			return;
		if(!wp_verify_nonce( $_POST['_update_sett_nonce'], '_set_options' ))
			return;
		if(isset($_POST['update_settings'])){
			if(isset($_POST['login_subscriber']))
				update_option('WLOG_subscriberLogin',$_POST['login_subscriber']);
			if(isset($_POST['logout_subscriber']))
				update_option('WLOG_subscriberLogout',$_POST['logout_subscriber']);
			if(isset($_POST['login_admin']))
				update_option('WLOG_adminLogin',$_POST['login_admin']);
			if(isset($_POST['logout_admin']))
				update_option('WLOG_adminLogout',$_POST['logout_admin']);	
		}
    }
    public function WLOG_login_logout_settings(){
    	if(!is_admin() || !current_user_can('manage_options'))
			return;
		$subscriberLogin = '';
		$subscriberLogout = '';
		$adminLogin = '';
		$adminLogout = '';
		if(get_option('WLOG_subscriberLogin'))
			$subscriberLogin = get_option('WLOG_subscriberLogin');
		if(get_option('WLOG_subscriberLogout'))
			$subscriberLogout = get_option('WLOG_subscriberLogout');
		if(get_option('WLOG_adminLogin'))
			$adminLogin = get_option('WLOG_adminLogin');
		if(get_option('WLOG_adminLogout'))
			$adminLogout = get_option('WLOG_adminLogout');
		?>
		<div class="settings_div">
			<h1>Redirection settings after login/ logout</h1>
			<form action="" method="POST">
				<?php wp_nonce_field( '_set_options', '_update_sett_nonce',true,true ); ?>
				<h2>Subscribers</h2>
				<table class="settings_table">
					<thead>
						<tr>
							<th><h3>Action</h3></th>
							<th><h3>Redirect to</h3></th>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td>Login</td>
							<td><input name="login_subscriber" id="login_subscriber" placeholder="Enter redirection url after login" value="<?php echo $subscriberLogin; ?>"/></td>
						</tr>
						<tr>
							<td>Logout</td>
							<td><input name="logout_subscriber" id="logout_subscriber" placeholder="Enter redirection url after logout" value="<?php echo $subscriberLogout; ?>"/></td>
						</tr>
					</tbody>
				</table>

				<h2>Admin</h2>
				<table class="settings_table">
					<thead>
						<tr>
							<th><h3>Action</h3></th>
							<th><h3>Redirect to</h3></th>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td>Login</td>
							<td><input name="login_admin" id="login_admin" placeholder="Enter redirection url after login" value="<?php echo $adminLogin; ?>"/></td>
						</tr>
						<tr>
							<td>Logout</td>
							<td><input name="logout_admin" id="logout_admin" placeholder="Enter redirection url after logout" value="<?php echo $adminLogout; ?>"/></td>
						</tr>
					</tbody>
				</table>
				<input type="submit" name="update_settings" id="update_settings" value="Update"/>
			</form>
		</div>
		<?php
    }

    function WLOG_add_scripts(){
    	wp_enqueue_style('wlog-admin-style', WLOG_direct_url. 'assets/css/login-settings.css');    	
    }
    function WLOG_add_scriptsFrontend(){
    	wp_enqueue_script('jquery');	
    	wp_enqueue_script('wlog-admin-script', WLOG_direct_url. 'assets/js/frontend-script.js');
    	wp_enqueue_style('wlog-frontend-style', WLOG_direct_url. 'assets/css/frontend.css'); 
    }
    function WLOG_add_loginout_link( $items, $args ) {
    	$item_counts = count($items);
    	if(strpos($this->items_classes, "menu-item") !== false){
    		$item_count = intval(preg_replace('/[^0-9]+/', '', $this->items_classes), 10);
    		$item_prev = "menu-item-".$item_count;
    		$item_count++;
    		$this->items_classes = str_replace($item_prev, "menu-item-".$item_count, $this->items_classes);
    	}    		
    	if (is_user_logged_in() && $args->theme_location == 'primary') {
    		$user = wp_get_current_user();
	 		$role = $user->roles[0];
	 		$logout_redirect = '';
    		if($role == "administrator")
				$logout_redirect = get_option('WLOG_adminLogout');
			else if($role == "administrator")
				$logout_redirect = get_option('WLOG_subscriberLogout');
	        $items .= '<li class="'.$this->items_classes.'"><a href="'. wp_logout_url($logout_redirect) .'">Log Out</a></li>';
	    }
	    elseif (!is_user_logged_in() && $args->theme_location == 'primary') {
	        $items .= '<li class="'.$this->items_classes.'" id="wlog_login"><a onclick="wlog_login_user()">Log In</a></li>';
	    }
	    return $items;
	}

	function WLOG_get_nav_class( $classes, $item ) {
	    $this->items_classes = implode(" ", $classes);
	    return $classes;
	}
	function WLOG_create_login(){
		?>
		<!-- <div id="container">
		    <div id="exampleModal" class="reveal-modal">
		    ........
		    <a href="#">Close Modal</a>
		    </div>
		</div> -->
		<?php
	}
}

// <div id="container_overlay"></div>
// 			<div id="container">
// 			    <div>
// 			    	<input name="wlogin_username" id="wlogin_username" type="text" placeholder="Enter username"/>
// 			    	<input name="wlogin_password" id="wlogin_password" type="text" placeholder="Enter Password"/>
// 				</div>
// 				<div class="login_wp"><a class="button">login</a></div>
// 			</div>