jQuery(document).ready(function(){

});

function wlog_login_user(){
	//console.log("sadsa");
}