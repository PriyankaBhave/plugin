<?php

/*
* Plugin Name: Login
*/

//if(is_admin() || current_user_can('manage_options')){    
    $class = new WLOG_initiate_login();
//}

final class WLOG_initiate_login {
	public function __construct() {
        $this->WLOG_initiase_constant(); 
		$this->WLOG_init_hooks();                       
	}
    public function WLOG_init_hooks() {
    	register_activation_hook(__FILE__,array($this, 'WLOG_activating_plugincode'));
        include_once WLOG_direct_path.'includes/load-options.php';
        new WLOG_options_login();
    }

    public function WLOG_initiase_constant(){
        define('WLOG_direct_path', plugin_dir_path(__FILE__));
        define('WLOG_direct_url', plugin_dir_url(__FILE__));
    }
    public function WLOG_activating_plugincode(){
        if(!is_admin() || !current_user_can('manage_options'))
            return;
        update_option('WLOG_status','activated');
    }
}
