=== Order Note template ===
Contributors: priyankabhave
Donate link: https://wordpress.org/plugins/woocommerce-order-note-templates
Tags: e-commerce, store, order note, customer note
Requires at least: 4.0
Tested up to: 4.4.5
Stable tag: 1.0
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Creates order notes (customer and private note) templates for woocommerce and use it on woocommerce order page to add note to the orders  

== Description ==

This plugin provides functionality to create woocommerce order notes templates and then use these templates to add notes(customer note or private note) to the customer orders on the main shop order page of the woocommerce.

Steps to create order note templates:

1. Open submenu "Order note template" from "woocommerce" menu
2. Now click on Add new order Template.
3. Add the title of the order note,  select the type whether the template will be used as customer note or private note
4. Enter the content for the order note to be sent.
5. Then save the templates.

To use the templates on the woocommerce shop order page

1. Open the submenu order from woocommerce menu
2. In the action column, an icon with tooltip Add notes will be present.
3. Click on the Add note for adding a note to a order, then a popup will be displayed.
4. From the popup select the order note type, after which a message will be displayed for the selected note in the text area, user can edit the message displayed in the text area.
5. Now click on the Add note, if the added note is customer note then customer note will be added and a mail will sent to customer or if it is private note then private note will be added only to the order.

== Installation ==

= Manual Installation =

1. Upload the plugin files to the `/wp-content/plugins/` directory, 
2. Unzip the file
3. Activate the plugin through the 'Plugins' screen in WordPress

=Automatic Installation=

1. Login to the dashboard.
2. Go to the plugins menu then click on the Add new then either upload the plugin if you have downloaded or search the plugin from the search box.
3. Go to the search box and type woocommerce order note template.
4. Now select the plugin then click on install.

== Frequently Asked Questions ==

= What is the benefit of using the plugin =
User can create the note templates that he usually sends to a customer or add note for his reference. User can also add the order notes directly from the shop order page, user doesn’t need to open individual order page then type the message. It saves time, reduces the retyping the same message for different customers. 

=  It is useful for the which type of user= 
It is mainly useful for the shop manager who manages the woocomemrce orders from the dashboard.

== Screenshots ==

1. AddNewOrderNoteTemplate.jpg
Displays the order note template page where on click of "Add new order note template" a block will be added for the template, there Enter the order note title, select the note type and enter the content for the notes.
2. orders.jpg
Displays the woocommerce orders page, where in the actions column click on the icon with tool tip Add note.
3. Addnote.jpg
In the popup select the order note and the content of the selected note display in the text area. Now click on the Add note to add the order note.
4. customerNote.jpg 
Template content will be sent in the customer note mail like the screenshot. 
5. delete note.jpg
To delete any template click on the - icon. 

== Changelog ==

= 1.0 =
* First version.

== Upgrade Notice ==
= 1.0 =
New version is available kindly check on the plugin page.
