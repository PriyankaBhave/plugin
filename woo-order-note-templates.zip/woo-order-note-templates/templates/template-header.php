<h2>Order Note Settings</h2>
<button class="add_order_note" >Add new order note template</button>
<span class="note">*click on - icon on the left of note template to delete template.</span>
<form method="post">
	<div class="main_template_block">