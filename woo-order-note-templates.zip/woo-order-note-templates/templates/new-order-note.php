
<div class="template_notes div_block">
	<span class="dashicons dashicons-minus delete_current_template" style = 'content: "\f460";'></span>
	<div class="template_div">
		<div>
			<input name ="post_id" value="0" type="hidden" class = "post_id" />
			<input class="template_title" />
		</div>
		<div>
			<select class="note_type" >
				<option value = "customer">Customer Note</option>
				<option value = "private">Private Note</option>
			</select>
		</div>
		<div>
			<textarea class="template_block_area"></textarea>
		</div>
	</div>
</div>
	
