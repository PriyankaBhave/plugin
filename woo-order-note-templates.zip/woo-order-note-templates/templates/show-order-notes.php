<?php 
foreach ($templates as $template ) : ?>
<div class="template_notes div_block">
	<span class="dashicons dashicons-minus delete_current_template" style = 'content: "\f460";'></span>
	<div class="template_div">
		<div>
			<input name ="post_id" value="<?php echo $template['Id']; ?>" type="hidden" class = "post_id" />
			<input class="template_title" value = "<?php echo $template['title']; ?>"/>
		</div>
		<div>
			<select class="note_type">
			
			<?php if($template["type"] == "customer") 
			{	
				echo '<option value = "customer" selected>Customer Note</option>'; 
				echo '<option value = "private" >Private Note</option>';
			}
			else
			{
				echo '<option value = "customer" >Customer Note</option>';
				echo '<option value = "private" selected>Private Note</option>';
			}
			?>
			</select>
		</div>
		<div>
			<textarea class="template_block_area" ><?php echo $template['content'] ?></textarea>
		</div>
	</div>
</div>

<?php endforeach; ?>	