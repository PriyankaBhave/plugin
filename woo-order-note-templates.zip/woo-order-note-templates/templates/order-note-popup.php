<link rel="stylesheet" href="<?php echo TEMPLATEURL?>admin/css/jquery-ui.min.css">
<script src="<?php echo TEMPLATEURL?>admin/js/jquery.min.js"></script>
<script src="<?php echo TEMPLATEURL?>admin/js/jquery-ui.js"></script>
<div id="dialog" title="<?php _e('Add Order Note', 'woocommerce'); ?>" style="display:none;">
    <div class="add_note" style="border:none;">    
        <p>
            <label>Customer Name:</label>
            <input type="text" name="customer_name" id="customer_name" style="width:250px;" readonly="readonly">
            <input type="hidden" id = "added_note_type">
        </p>

        <p>
            <label>Order Id:</label>
            <input type="text" name="order_id" id="order_post_id" style="width:250px;" readonly="readonly">
        </p>
        <p>
            <label>Order Note Type:</label>
            <select name="order_note_type" id="add_order_note_type" style="width:250px;">
            <option >Please select the order note type</option>
                <?php if($templates) 
                    {
                      foreach($templates as $index => $template) : ?>
                      <option value="<?php if($template['type'] == 'customer') echo 'customer'; else echo'private'; ?>" id="<?php echo $index;?>"><?php echo $template["title"]; ?></option>
                      <?php endforeach; 
                    }
                    else
                    { ?>
                        <option value="customer" id="0">Customer Note</option>
                        <option value="private" id="0">Private Note</option>
                    <?php } ?> 
            </select>
           
        </p>
        <p>
            <label>Order Note:</label>
            
                <textarea type="text" name="order_note" id="add_order_note_text" class="input-text" cols="20" rows="6" ></textarea>
        </p>
        <p id="gyrix_default_content">
            <?php if($templates)
            {
                foreach($templates as $index => $template) : ?>
                <textarea type="text" id="<?php echo 'gyrix_content-'.$index; ?>" ><?php echo $template["content"]; ?></textarea>
                <?php endforeach;
            }?> 
        </p>
        <p style="text-align:center;">
            <a href="" class="add_note_to_order button"><?php _e('Add Note', 'woocommerce'); ?></a>
        </p>
    </div>
</div>