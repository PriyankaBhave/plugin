<?php
/*
Page for order notes template
*/
class order_note_load_display
{
	public function load_template_page() 
	{
		$note = new order_note_view;
		$templates = $note->get_note_template();
		include TEMPLATEPATH."/templates/template-header.php";
		if($templates)
			include TEMPLATEPATH."/templates/show-order-notes.php";
		else
			include TEMPLATEPATH."/templates/new-order-note.php";				
		include TEMPLATEPATH."/templates/template-footer.php";
		
	}	
}