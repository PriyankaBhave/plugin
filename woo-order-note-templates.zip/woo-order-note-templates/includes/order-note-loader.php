<?php
/*
Include css and js files
*/
class order_note_manager_load
{
    protected $note_template;
     
	public function enqueue_styles() 
    {
        wp_enqueue_style(
            'templatecss',
            TEMPLATEURL . 'admin/css/templatecss.min.css',
            array(), 
            '1.0.0', 
            all 

        );
    }

    public function enqueue_jscript() 
    {
        wp_enqueue_script(
                'customjs.js',
                TEMPLATEURL . 'admin/js/script.min.js',
                array(), 
                '1.0.0' 
            );
    }

    // Add submenu to the woocommerce
	public function hooks()
    {
        $template = new order_note_load_display;
        $this->note_template = add_submenu_page(
                                        'woocommerce', 
                                        'Order Note Template', 
                                        'Order Note Template', 
                                        'manage_options', 
                                        'order-note-settings',
                                        array($template, 'load_template_page')
                                        );
    }
    // Add "Add note" icon to the action column in order note
    function filter_woocommerce_admin_order_actions( $add_globalpay_requery_button) 
    {
        global $woocommerce;

        $add_globalpay_requery_button['note'] = array(
                                                      'name'      => "Add Notes",
                                                      'action'    => "shop_order-note"
                                                  );


        return $add_globalpay_requery_button;
    }

    public function action_woocommerce_admin_order_actions_end( $instance ) 
    {
        $note = new order_note_view;
        $value = "test";
        $templates = $note->get_note_template();
        include (TEMPLATEPATH."templates/order-note-popup.php");      
    }
    
}



