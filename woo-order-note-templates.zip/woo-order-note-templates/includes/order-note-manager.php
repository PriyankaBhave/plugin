<?php
/*
Hook list
*/
class order_note_manager
{
	private $my_plugin_screen_name;
    
    private static $instance;

    static function get_instance()
	{	      
	    if (!isset(self::$instance))
	    {
	        self::$instance = new self();
	    }
	    return self::$instance;
	}

	public function __construct() {
		// $this->define_constants();
		$this->init_plugin();
	}

	public function load_files()
	{
	   	require_once 'order-note-loader.php';
	   	require_once 'order-note-display.php';
	   	include(TEMPLATEPATH.'/admin/inc/order-note-save.php');
	   	include(TEMPLATEPATH.'/admin/inc/order-note-view.php');
	} 
	public function init_plugin()
	{

		$this->load_files();
		$hook = new order_note_manager_load;
		add_action('admin_menu', array($hook, 'hooks'));
    	add_action( 'admin_enqueue_scripts', array($hook, 'enqueue_styles' ));
    	add_action( 'admin_enqueue_scripts', array($hook, 'enqueue_jscript' ));
    	add_filter( 'woocommerce_admin_order_actions',array($hook, 'filter_woocommerce_admin_order_actions'), 10, 3 );
    	add_action( 'woocommerce_admin_order_actions_end',array($hook, 'action_woocommerce_admin_order_actions_end'), 10, 1 );
    	remove_filter ('the_content',  'wpautop');				
    	$note = new save_note_template;
		add_action('wp_ajax_save_templates',array($note ,'save_templates'));
		add_action('wp_ajax_get_customer_name',array($note ,'get_customer_name'));
		add_action('wp_ajax_add_order_note',array($note ,'add_order_note'));
	}
	public function register_cpt()
	{
		$labels = array(
	        'name' => "Gyrix Note Template",
	        'singular_name' => "Gyrix Note Template"
	         );

	        $args = array(
	        'labels' => $labels,
	        'show_in_menu' => false,
	    );  
	    register_post_type( "gyrix_note_template", $args );
	}
}
