<?php

/*
Uninstall plugin
*/

// If uninstall is not called from WordPress, exit
if ( !defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit();
}

uninstall_templete_data();
function uninstall_templete_data()
{
	$args = array(
	'posts_per_page'   => -1,
	'orderby'          => 'date',
	'order'            => 'DESC',
	'post_type'        => 'gyrix_note_template',
	
	);
	$the_query = new WP_Query( $args );
	$posts = $the_query->get_posts();
	foreach ($posts as $post) 
	{
		delete_post_meta ( $post->ID, 'gyrix_note_type');
		wp_delete_post($post->ID);	
	}
}
