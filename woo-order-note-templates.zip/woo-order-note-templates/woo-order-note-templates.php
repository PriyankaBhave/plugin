<?php
/*
* Plugin Name: Woo Order Note Templates
* Plugin URI: https://wordpress.org/plugins/woocommerce-order-note-templates
* Description: Creates Order Note templates for the woocommerce and use these templates for adding notes to the orders from order page 
* Version: 1.0
* Author: Priyanka Bhave
* Requires at least: 4.1
* Tested up to: 4.2.2
*/

if (!defined('ABSPATH'))

{
    exit; // Exit if accessed directly
}

if(!defined('TEMPLATEPATH'))
{
	define('TEMPLATEPATH', plugin_dir_path(__FILE__));

	define('TEMPLATEURL', plugin_dir_url(__FILE__));

	define('TEMPLATENAME', plugin_basename(__FILE__));
}
require_once '/includes/order-note-manager.php';
function order_note_template_run() 
{	
	register_activation_hook( __FILE__, array( 'order_note_manager', 'register_cpt' ) );
	order_note_manager::get_instance();
}
add_action( 'init', 'order_note_template_run' );


// to de-activate plugin
function pluginprefix_deactivation() 
{
    flush_rewrite_rules(); 
}
register_deactivation_hook( __FILE__, 'pluginprefix_deactivation' );

